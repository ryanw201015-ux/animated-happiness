# Spring Bonnie: Night Notes

A mobile-first, installable Progressive Web App (PWA) fan-made notes app.

## Features
- Create, edit, search, and delete notes
- Saves notes in this browser on this device using local storage
- Export notes to TXT or a JSON backup
- Import a JSON backup
- Dark purple/gold horror-inspired interface
- Offline shell after first successful load when hosted over HTTPS

## Install on Android
PWA installation requires the files to be hosted on an HTTPS website (or localhost). A downloaded ZIP alone cannot be installed as a PWA directly.

1. Upload the contents of this folder to an HTTPS static host (for example, a GitHub Pages site).
2. Open the hosted site in Chrome on your Android phone.
3. Open Chrome's menu (⋮) and choose **Install app** or **Add to Home screen**.
4. Launch **Night Notes** from your home screen.

## Local use
You can open `index.html` in a browser for a basic preview, but PWA install and offline caching need HTTPS hosting.

## Important storage note
Notes stay in the browser storage on the current device. Clearing browser/site data can erase them. Use **Backup JSON** regularly and import the backup on another device to transfer notes.

This is an unofficial fan-made project and is not affiliated with or endorsed by Five Nights at Freddy's / its rights holders.
